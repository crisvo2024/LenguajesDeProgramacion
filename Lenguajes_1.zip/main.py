#Juan Esteban Rozo Urbina
#David Alexander Arias Parra
#Cristian Santiago Vargas Ortiz

from AnalizadorSintactico import AnalizadorSintactico

if __name__ == "__main__":
	AnaSinc=AnalizadorSintactico()
	AnaSinc.analizar()

